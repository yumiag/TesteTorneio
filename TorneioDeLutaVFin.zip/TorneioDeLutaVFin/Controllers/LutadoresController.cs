﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using TorneioDeLutaVFin.Models;


namespace TorneioDeLutaVFin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class LutadoresController : ControllerBase
    {

        List<Lutador> lutadores = new List<Lutador>();

        private readonly IHostingEnvironment _env;
        public LutadoresController(IHostingEnvironment env)
        {
            _env = env;
        }
        [HttpGet]

        //PEGA TODOS LUTADORES CRIADOS
        public IActionResult GetAllLutadores()
        {

            return Ok(getLutador());

        }

        public List<Lutador> getLutador ()
        {
            var client = new HttpClient();
            client.BaseAddress = new System.Uri("https://apidev-mbb.t-systems.com.br:8443/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("x-api-key", "e07cb70a-7e83-486b-b88d-7b2b180d7299");
            HttpResponseMessage response = client.GetAsync("edgemicro_tsdev/torneioluta/api/competidores").Result;
            var jsonString = response.Content.ReadAsStringAsync();
            jsonString.Wait();
            lutadores = JsonConvert.DeserializeObject<List<Lutador>>(jsonString.Result);
            return lutadores;
        }
    }
}
